def hw():
    print('Hello, World!', end='')
    return
    
hw()
